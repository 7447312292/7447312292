<form id="contact-form" method="post" action="contact.php">

<div class="messages"></div>
<div class="controls">

    <div class="form-group">
        <input id="form_name" type="text" name="name" class="form-control" placeholder="Enter your name." required="required">
    </div>

    <div class="form-group">
        <input id="form_email" type="email" name="email" class="form-control" placeholder="Enter your email." required="required">
    </div>

    <div class="form-group">
        <textarea id="form_message" name="message" class="form-control" placeholder="Add your message." rows="4" required="required"></textarea>
    </div>

    <input type="submit" class="btn btn-outline-light btn-sm" value="Send message">

</div>

</form>


<?php

use PHPMailer\PHPMailer\PHPMailer;

require './PHPMailer-master/vendor/autoload.php';

$fromEmail = 'rajatvinkal01@gmail.com';
$fromName = 'Rajat Ganorkar';

$sendToEmail = 'rajatrajatganorkar@gmail.com';
$sendToName = 'New Website Email Message';

$subject = 'Subject';

$fields = array('name' => 'Name:', 'email' => 'Email:', 'message' => 'Message:');

$okMessage = 'Successfully submitted - we will get back to you soon!';

$errorMessage = 'There was an error while submitting the form. Please try again later';


error_reporting(E_ALL & ~E_NOTICE);

try
{

if(count($_POST) == 0) throw new \Exception('Form is empty');
$emailTextHtml .= "<h3>New message from website:</h3><hr>";
$emailTextHtml .= "<table>";

foreach ($_POST as $key => $value) {

if (isset($fields[$key])) {
    $emailTextHtml .= "<tr><th>$fields[$key]</th><td>$value</td></tr>";
}
}
$emailTextHtml .= "</table><hr>";
$emailTextHtml .= "<p>Have a great day!</p>";

$mail = new PHPMailer;

$mail->setFrom($fromEmail, $fromName);
$mail->addAddress($sendToEmail, $sendToName);
$mail->addReplyTo($_POST['email'], $_POST['name']);


$mail->Subject = $subject;

$mail->Body = $emailTextHtml;
$mail->isHTML(true);

if(!$mail->send()) {
throw new \Exception('Email send failed. ' . $mail->ErrorInfo);
}

$responseArray = array('type' => 'success', 'message' => $okMessage);
}
catch (\Exception $e)
{
$responseArray = array('type' => 'danger', 'message' => $e->getMessage());
}


if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
$encoded = json_encode($responseArray);

header('Content-Type: application/json');

echo $encoded;
}
else {
echo $responseArray['message'];
}
?>
